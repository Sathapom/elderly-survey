/**
 * แบบสำรวจผู้สูงอายุที่ถูกละเลยทอดทิ้ง (admit ใน รพ.ศูนย์/รพ.ทั่วไป)
 * Backend: Google Apps Script + Google Sheets
 *
 * แท็บที่ใช้
 *   hospital  : รายชื่อ รพ. (มีอยู่แล้ว) คอลัมน์ Code, Name, Region, Level, TotalBeds ...
 *   responses : 1 แถว / 1 รพ. ที่ตอบแล้ว (สร้างอัตโนมัติ)
 *   patients  : 1 แถว / ผู้ป่วย 1 คน (สร้างอัตโนมัติ)
 *
 * อยากเปิดให้ รพ. ส่งใหม่ → ลบแถวของ รพ. นั้นในแท็บ responses และ patients
 */

const SPREADSHEET_ID = '1iY2xCO9a9kepy3mH3NntddKr29aWG5WVZzx5a0QD_ik';

const RESP_HEADERS = [
  'Timestamp', 'Code', 'Name', 'Region', 'Level',
  'BedsActual', 'OccupancyPct', 'ContactName', 'ContactPosition', 'ContactPhone', 'ContactEmail', 'Approver',
  'NoPatients', 'TotalPatients', 'Male', 'Female', 'ReadyDischarge', 'StillTreating',
  'BedsGeneral', 'BedsSpecial', 'BedsICU', 'ExcessDaysTotal', 'CostAfterReady', 'Past12Months',
  'Problems', 'ProblemOther', 'Support1', 'Support2', 'Support3', 'UrgentCases', 'Suggestion'
];

const PT_HEADERS = [
  'Timestamp', 'HospCode', 'HospName', 'Region', 'PatientCode', 'Sex', 'Age', 'Right', 'IdStatus',
  'Ward', 'BedType', 'AdmitDate', 'ReadyDate', 'ExcessDays', 'Diagnosis', 'ADL', 'Dependency',
  'SpecialCare', 'FamilyStatus', 'MainReason', 'Coordination', 'Placement'
];

function ss_() { return SpreadsheetApp.openById(SPREADSHEET_ID); }

function sheet_(name, headers) {
  const ss = ss_();
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

/** รันครั้งเดียวจากเมนู Run เพื่อสร้างแท็บและอนุญาตสิทธิ์ */
function setup() {
  sheet_('responses', RESP_HEADERS);
  sheet_('patients', PT_HEADERS);
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function rows_(name, headers) {
  const sh = sheet_(name, headers);
  const v = sh.getDataRange().getValues();
  const h = v.shift();
  return v.filter(r => r.join('') !== '').map(r => {
    const o = {}; h.forEach((k, i) => o[k] = r[i] instanceof Date ? Utilities.formatDate(r[i], 'Asia/Bangkok', 'yyyy-MM-dd HH:mm') : r[i]); return o;
  });
}

function hospitals_() {
  const v = ss_().getSheetByName('hospital').getDataRange().getValues();
  const h = v.shift().map(String);
  const ix = k => h.indexOf(k);
  return v.filter(r => r[ix('Code')] !== '').map(r => ({
    code: String(r[ix('Code')]).trim(),
    name: String(r[ix('Name')]).trim(),
    region: String(r[ix('Region')]).trim(),
    level: String(r[ix('Level')]).trim(),
    beds: r[ix('TotalBeds')] === '' ? '' : Number(r[ix('TotalBeds')])
  }));
}

function answeredCodes_() {
  return new Set(rows_('responses', RESP_HEADERS).map(r => String(r.Code)));
}

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'hospitals';
  try {
    if (action === 'hospitals') {
      const done = answeredCodes_();
      return json_({ ok: true, hospitals: hospitals_().filter(h => !done.has(h.code)) });
    }
    if (action === 'dashboard') {
      return json_({
        ok: true,
        updated: Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm'),
        hospitals: hospitals_(),
        responses: rows_('responses', RESP_HEADERS),
        patients: rows_('patients', PT_HEADERS)
      });
    }
    return json_({ ok: false, error: 'unknown action' });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  }
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const d = JSON.parse(e.postData.contents);
    const code = String(d.code || '').trim();
    const hosp = hospitals_().find(h => h.code === code);
    if (!hosp) return json_({ ok: false, error: 'ไม่พบรหัสโรงพยาบาล' });
    if (answeredCodes_().has(code)) return json_({ ok: false, error: 'โรงพยาบาลนี้ส่งข้อมูลแล้ว หากต้องการแก้ไขโปรดติดต่อผู้ประสานงานส่วนกลาง' });

    const pts = d.noPatients ? [] : (d.patients || []);
    const now = new Date();
    const n = x => (x === '' || x == null || isNaN(Number(x))) ? '' : Number(x);

    // สรุปส่วนที่ 2 คำนวณจากรายคน (ไม่ให้ผู้ตอบกรอกซ้ำ)
    const s = { male: 0, female: 0, ready: 0, gen: 0, spe: 0, icu: 0, excess: 0 };
    pts.forEach(p => {
      if (p.sex === 'ชาย') s.male++; else if (p.sex === 'หญิง') s.female++;
      if (p.readyDate) { s.ready++; s.excess += Number(p.excessDays) || 0; }
      if (p.bedType === 'สามัญ') s.gen++; else if (p.bedType === 'พิเศษ') s.spe++; else if (p.bedType === 'ICU/กึ่งวิกฤต') s.icu++;
    });

    sheet_('responses', RESP_HEADERS).appendRow([
      now, code, hosp.name, hosp.region, hosp.level,
      n(d.bedsActual), n(d.occupancy), d.contactName || '', d.contactPosition || '', "'" + (d.contactPhone || ''), d.contactEmail || '', d.approver || '',
      d.noPatients ? 'ใช่' : '', pts.length, s.male, s.female, s.ready, pts.length - s.ready,
      s.gen, s.spe, s.icu, s.excess, n(d.cost), n(d.past12),
      (d.problems || []).join(', '), d.problemOther || '', d.support1 || '', d.support2 || '', d.support3 || '', d.urgent || '', d.suggestion || ''
    ]);

    if (pts.length) {
      const sh = sheet_('patients', PT_HEADERS);
      const rows = pts.map(p => [
        now, code, hosp.name, hosp.region, p.patientCode || '', p.sex || '', n(p.age), p.right || '', p.idStatus || '',
        p.ward || '', p.bedType || '', p.admitDate || '', p.readyDate || '', n(p.excessDays), p.diagnosis || '',
        n(p.adl), p.dependency || '', (p.specialCare || []).join(', '), p.family || '', p.reason || '', p.coordination || '', p.placement || ''
      ]);
      sh.getRange(sh.getLastRow() + 1, 1, rows.length, PT_HEADERS.length).setValues(rows);
    }
    return json_({ ok: true, count: pts.length });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}
